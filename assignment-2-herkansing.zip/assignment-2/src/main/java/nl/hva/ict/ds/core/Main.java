package nl.hva.ict.ds.core;

public class Main {

    public static void main(String[] args) {

    }
}
